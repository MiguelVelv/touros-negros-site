import Link from "next/link";
import { notFound } from "next/navigation";
import { ShoppingCart, ArrowLeft, ShieldCheck } from "lucide-react";
import { products } from "@/lib/products";
import AddToCart from "@/components/AddToCart";

export default async function ProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const product = products.find((item) => item.id === id);
  if (!product) notFound();

  return (
    <main className="min-h-screen py-10">
      <div className="container-shop">
        <Link href="/geral" className="mb-8 inline-flex items-center gap-2 text-sm text-zinc-500 hover:text-white"><ArrowLeft size={16} />Voltar para a loja</Link>
        <div className="grid gap-8 md:grid-cols-2">
          <div className="overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-950">
            <img src={product.image} alt={product.name} className="aspect-square h-full w-full object-cover" />
          </div>
          <div className="flex flex-col justify-center">
            <span className="mb-3 text-sm font-bold text-violet-400">{product.game}</span>
            <h1 className="text-3xl font-black md:text-4xl">{product.name}</h1>
            <p className="mt-5 leading-7 text-zinc-400">{product.description}</p>
            <div className="mt-8"><span className="text-sm text-zinc-500">Preço</span><div className="text-4xl font-black">R$ {product.price.toFixed(2).replace(".", ",")}</div></div>
            <div className="mt-6 flex items-center gap-3 text-sm text-emerald-400"><ShieldCheck size={19} />Produto disponível</div>
            <AddToCart product={product} />
          </div>
        </div>
      </div>
    </main>
  );
}