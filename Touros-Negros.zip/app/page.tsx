import Hero from "@/components/Hero";
import CategoryBar from "@/components/CategoryBar";
import ProductCard from "@/components/ProductCard";
import { products } from "@/lib/products";

export default function Home() {
  return (
    <main>
      <Hero />
      <CategoryBar />
      <section className="pb-12">
        <div className="container-shop">
          <div className="mb-6 flex items-end justify-between">
            <div>
              <h2 className="text-2xl font-black">Produtos em destaque</h2>
              <p className="mt-1 text-sm text-zinc-500">Confira nossas ofertas.</p>
            </div>
            <a href="/geral" className="text-sm font-semibold text-violet-400 hover:text-violet-300">Ver todos →</a>
          </div>
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {products.map((product) => <ProductCard key={product.id} product={product} />)}
          </div>
        </div>
      </section>
    </main>
  );
}