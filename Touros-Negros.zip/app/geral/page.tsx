 "use client";

import { useMemo, useState } from "react";
import { Search, SlidersHorizontal } from "lucide-react";
import ProductCard from "@/components/ProductCard";
import { products } from "@/lib/products";

export default function GeralPage() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("Todos");
  const categories = ["Todos", "Contas", "Itens", "Kits", "Moedas"];

  const filteredProducts = useMemo(() => products.filter((product) => {
    const matchesSearch = product.name.toLowerCase().includes(search.toLowerCase()) || product.game.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = category === "Todos" || product.category === category;
    return matchesSearch && matchesCategory;
  }), [search, category]);

  return (
    <main className="min-h-screen py-10">
      <div className="container-shop">
        <div className="mb-8">
          <h1 className="text-3xl font-black">Todos os produtos</h1>
          <p className="mt-2 text-zinc-500">Escolha seu produto e confira os detalhes.</p>
        </div>
        <div className="mb-8 grid gap-4 md:grid-cols-[1fr_auto]">
          <div className="flex items-center rounded-xl border border-zinc-800 bg-zinc-900 px-4">
            <Search size={19} className="text-zinc-500" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Pesquisar..." className="w-full bg-transparent px-3 py-3 outline-none" />
          </div>
          <div className="flex items-center gap-2 overflow-x-auto">
            <SlidersHorizontal size={19} className="shrink-0 text-zinc-500" />
            {categories.map((item) => (
              <button key={item} onClick={() => setCategory(item)} className={`whitespace-nowrap rounded-xl border px-4 py-3 text-sm font-semibold ${category === item ? "border-violet-600 bg-violet-600" : "border-zinc-800 bg-zinc-900 text-zinc-400"}`}>
                {item}
              </button>
            ))}
          </div>
        </div>
        {filteredProducts.length === 0 ? (
          <div className="rounded-2xl border border-zinc-800 bg-zinc-900 p-12 text-center">
            <h2 className="text-xl font-bold">Nenhum produto encontrado</h2>
            <p className="mt-2 text-sm text-zinc-500">Tente pesquisar por outro nome.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {filteredProducts.map((product) => <ProductCard key={product.id} product={product} />)}
          </div>
        )}
      </div>
    </main>
  );
}